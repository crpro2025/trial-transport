'use client';

import { useParams, useRouter } from 'next/navigation';
import { ArrowLeft, Download } from 'lucide-react';
import { useEffect, useState } from 'react';

export default function DocumentPage() {
  const params = useParams();
  const router = useRouter();
  const [content, setContent] = useState('');
  const [loading, setLoading] = useState(true);

  const documents: { [key: string]: { title: string; file: string } } = {
    'pitch-deck': {
      title: 'Investor Pitch Deck',
      file: '/docs/INVESTOR_PITCH_DECK_FINAL.md',
    },
    'executive-summary': {
      title: 'Executive Summary',
      file: '/docs/EXECUTIVE_SUMMARY.md',
    },
    'one-pager': {
      title: 'One-Pager',
      file: '/docs/ONE_PAGER.md',
    },
    'features-roadmap': {
      title: 'Advanced Features Roadmap',
      file: '/docs/ADVANCED_FEATURES_ROADMAP.md',
    },
    'materials-guide': {
      title: 'Complete Materials Guide',
      file: '/docs/INVESTOR_MATERIALS_COMPLETE.md',
    },
  };

  const slug = params.slug as string;
  const doc = documents[slug];

  useEffect(() => {
    if (doc) {
      fetch(doc.file)
        .then((res) => res.text())
        .then((text) => {
          setContent(text);
          setLoading(false);
        })
        .catch((err) => {
          console.error('Error loading document:', err);
          setLoading(false);
        });
    }
  }, [doc]);

  if (!doc) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white mb-4">Document Not Found</h1>
          <button
            onClick={() => router.push('/investors')}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg font-semibold hover:shadow-lg transition-all"
          >
            Back to Investor Resources
          </button>
        </div>
      </div>
    );
  }

  const downloadAsText = () => {
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${slug}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Animated Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Content */}
      <div className="relative z-10">
        {/* Header */}
        <div className="bg-white/5 backdrop-blur-xl border-b border-white/10 sticky top-0 z-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <button
                onClick={() => router.push('/investors')}
                className="flex items-center gap-2 text-gray-300 hover:text-white transition-colors"
              >
                <ArrowLeft className="w-5 h-5" />
                Back to Investor Resources
              </button>
              <button
                onClick={downloadAsText}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-500 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
              >
                <Download className="w-4 h-4" />
                Download as Text
              </button>
            </div>
          </div>
        </div>

        {/* Document Content */}
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 md:p-12">
            <h1 className="text-4xl font-bold text-white mb-8">{doc.title}</h1>
            
            {loading ? (
              <div className="text-center py-12">
                <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-400"></div>
                <p className="text-gray-400 mt-4">Loading document...</p>
              </div>
            ) : (
              <div className="prose prose-invert prose-cyan max-w-none">
                <pre className="whitespace-pre-wrap text-gray-300 font-mono text-sm leading-relaxed">
                  {content}
                </pre>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}