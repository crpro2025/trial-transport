'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Package, Users, Settings, DollarSign, BarChart, FileText, Award, Calendar, User } from 'lucide-react';

interface DashboardNavigationProps {
  role: 'admin' | 'shipper' | 'driver';
}

export function DashboardNavigation({ role }: DashboardNavigationProps) {
  const pathname = usePathname();

  const isActive = (path: string) => pathname === path;

  const adminLinks = [
    { href: '/admin/dashboard', label: 'Dashboard', icon: Home },
    { href: '/admin/users', label: 'Users', icon: Users },
    { href: '/admin/shipments', label: 'Shipments', icon: Package },
    { href: '/admin/billing', label: 'Billing', icon: DollarSign },
  ];

  const shipperLinks = [
    { href: '/shipper/dashboard', label: 'Dashboard', icon: Home },
    { href: '/shipper/shipments', label: 'Shipments', icon: Package },
    { href: '/shipper/templates', label: 'Templates', icon: FileText },
    { href: '/shipper/calculator', label: 'Calculator', icon: BarChart },
    { href: '/shipper/create-shipment', label: 'New Shipment', icon: Package },
    { href: '/shipper/billing', label: 'Billing', icon: DollarSign },
  ];

  const driverLinks = [
    { href: '/driver/dashboard', label: 'Dashboard', icon: Home },
    { href: '/driver/available', label: 'Available', icon: Package },
    { href: '/driver/training', label: 'Training', icon: Award },
    { href: '/driver/profile', label: 'Profile', icon: User },
    { href: '/driver/availability', label: 'Availability', icon: Calendar },
    { href: '/driver/earnings', label: 'Earnings', icon: DollarSign },
  ];

  const links = role === 'admin' ? adminLinks : role === 'shipper' ? shipperLinks : driverLinks;

  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex space-x-8 overflow-x-auto">
          {links.map((link) => {
            const Icon = link.icon;
            return (
              <Link
                key={link.href}
                href={link.href}
                className={`flex items-center gap-2 py-4 px-3 border-b-2 text-sm font-medium whitespace-nowrap ${
                  isActive(link.href)
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Icon className="w-4 h-4" />
                {link.label}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}